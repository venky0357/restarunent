package com.yitsapplication.app

import com.yitsapplication.app.appcomponents.base.BaseActivity
import com.yitsapplication.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}