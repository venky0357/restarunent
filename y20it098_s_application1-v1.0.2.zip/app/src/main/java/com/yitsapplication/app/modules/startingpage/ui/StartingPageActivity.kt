package com.yitsapplication.app.modules.startingpage.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.base.BaseActivity
import com.yitsapplication.app.databinding.ActivityStartingPageBinding
import com.yitsapplication.app.modules.loginpage.ui.LoginPageActivity
import com.yitsapplication.app.modules.startingpage.`data`.viewmodel.StartingPageVM
import kotlin.String
import kotlin.Unit

class StartingPageActivity :
    BaseActivity<ActivityStartingPageBinding>(R.layout.activity_starting_page) {
  private val viewModel: StartingPageVM by viewModels<StartingPageVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.startingPageVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = LoginPageActivity.getIntent(this, null)
      startActivity(destIntent)
      finish()
      }, 3000)
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "STARTING_PAGE_ACTIVITY"

    }
  }
