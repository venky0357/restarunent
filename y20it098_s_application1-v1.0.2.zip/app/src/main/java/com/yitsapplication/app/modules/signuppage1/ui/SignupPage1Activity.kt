package com.yitsapplication.app.modules.signuppage1.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.base.BaseActivity
import com.yitsapplication.app.databinding.ActivitySignupPage1Binding
import com.yitsapplication.app.modules.loginpage.ui.LoginPageActivity
import com.yitsapplication.app.modules.signuppage1.`data`.viewmodel.SignupPage1VM
import com.yitsapplication.app.modules.signuppage2.ui.SignupPage2Activity
import kotlin.String
import kotlin.Unit

class SignupPage1Activity :
    BaseActivity<ActivitySignupPage1Binding>(R.layout.activity_signup_page_1) {
  private val viewModel: SignupPage1VM by viewModels<SignupPage1VM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.signupPage1VM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.etGroupTwentyTwo.setOnClickListener {
      val destIntent = SignupPage2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnCreateAccount.setOnClickListener {
      val destIntent = LoginPageActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.viewCreatefromfraOne.setOnClickListener {
      val destIntent = SignupPage2Activity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "SIGNUP_PAGE1ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, SignupPage1Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
