package com.yitsapplication.app.modules.verifyphonenumber.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.base.BaseActivity
import com.yitsapplication.app.databinding.ActivityVerifyPhoneNumberBinding
import com.yitsapplication.app.modules.verifyphonenumber.`data`.viewmodel.VerifyPhoneNumberVM
import kotlin.String
import kotlin.Unit

class VerifyPhoneNumberActivity :
    BaseActivity<ActivityVerifyPhoneNumberBinding>(R.layout.activity_verify_phone_number) {
  private val viewModel: VerifyPhoneNumberVM by viewModels<VerifyPhoneNumberVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.verifyPhoneNumberVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "VERIFY_PHONE_NUMBER_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, VerifyPhoneNumberActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
