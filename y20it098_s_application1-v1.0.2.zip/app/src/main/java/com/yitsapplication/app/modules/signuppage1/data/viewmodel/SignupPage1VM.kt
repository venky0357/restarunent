package com.yitsapplication.app.modules.signuppage1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.yitsapplication.app.modules.signuppage1.`data`.model.SignupPage1Model
import org.koin.core.KoinComponent

class SignupPage1VM : ViewModel(), KoinComponent {
  val signupPage1Model: MutableLiveData<SignupPage1Model> = MutableLiveData(SignupPage1Model())

  var navArguments: Bundle? = null
}
