package com.yitsapplication.app.modules.startingpage.`data`.model

import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class StartingPageModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtQuickBite: String? = MyApp.getInstance().resources.getString(R.string.lbl_quickbite)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFoodDeliveryA: String? =
      MyApp.getInstance().resources.getString(R.string.msg_food_delivery_a)

)
