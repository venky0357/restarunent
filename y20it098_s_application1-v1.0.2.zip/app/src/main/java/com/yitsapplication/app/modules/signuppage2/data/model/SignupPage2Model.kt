package com.yitsapplication.app.modules.signuppage2.`data`.model

import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class SignupPage2Model(
  /**
   * TODO Replace with dynamic value
   */
  var txtQuickBite: String? = MyApp.getInstance().resources.getString(R.string.lbl_quickbite)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGetstartedwit: String? = MyApp.getInstance().resources.getString(R.string.lbl_new_user2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLabel: String? = MyApp.getInstance().resources.getString(R.string.lbl_charity_name)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLabelOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_full_name)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLabelTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_mobile_number)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGenderOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_female)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupElevenValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwelveValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTenValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupEightValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupSixValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGenderValue: String? = null
)
