package com.yitsapplication.app.modules.signuppage2.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.yitsapplication.app.modules.signuppage2.`data`.model.SignupPage2Model
import org.koin.core.KoinComponent

class SignupPage2VM : ViewModel(), KoinComponent {
  val signupPage2Model: MutableLiveData<SignupPage2Model> = MutableLiveData(SignupPage2Model())

  var navArguments: Bundle? = null
}
