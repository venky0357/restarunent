package com.yitsapplication.app.modules.loginpage.`data`.model

import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class LoginPageModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtQuickBite: String? = MyApp.getInstance().resources.getString(R.string.lbl_quickbite)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGetstartedwit: String? = MyApp.getInstance().resources.getString(R.string.lbl_login_user)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEnteryourphon: String? =
      MyApp.getInstance().resources.getString(R.string.msg_enter_your_phon)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLabel: String? = MyApp.getInstance().resources.getString(R.string.lbl_phone_number)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEightyFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_91)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_xxx_xxx_xxxx)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNewUser: String? = MyApp.getInstance().resources.getString(R.string.lbl_new_user)

)
