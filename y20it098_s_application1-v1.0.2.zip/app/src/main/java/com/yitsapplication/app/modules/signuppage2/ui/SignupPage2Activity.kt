package com.yitsapplication.app.modules.signuppage2.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.base.BaseActivity
import com.yitsapplication.app.databinding.ActivitySignupPage2Binding
import com.yitsapplication.app.modules.loginpage.ui.LoginPageActivity
import com.yitsapplication.app.modules.signuppage1.ui.SignupPage1Activity
import com.yitsapplication.app.modules.signuppage2.`data`.viewmodel.SignupPage2VM
import kotlin.String
import kotlin.Unit

class SignupPage2Activity :
    BaseActivity<ActivitySignupPage2Binding>(R.layout.activity_signup_page_2) {
  private val viewModel: SignupPage2VM by viewModels<SignupPage2VM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.signupPage2VM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnCreateAccount.setOnClickListener {
      val destIntent = LoginPageActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.etGroupEleven.setOnClickListener {
      val destIntent = SignupPage1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.viewCreatefromfra.setOnClickListener {
      val destIntent = SignupPage1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "SIGNUP_PAGE2ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, SignupPage2Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
