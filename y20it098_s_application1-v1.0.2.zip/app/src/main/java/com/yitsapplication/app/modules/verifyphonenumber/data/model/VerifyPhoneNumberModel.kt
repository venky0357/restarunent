package com.yitsapplication.app.modules.verifyphonenumber.`data`.model

import com.yitsapplication.app.R
import com.yitsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class VerifyPhoneNumberModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtQuickBite: String? = MyApp.getInstance().resources.getString(R.string.lbl_quickbite)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtVerifyphonenu: String? =
      MyApp.getInstance().resources.getString(R.string.msg_verify_phone_nu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWehavejustse: String? =
      MyApp.getInstance().resources.getString(R.string.msg_we_have_just_se)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumber: String? = MyApp.getInstance().resources.getString(R.string.lbl_1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_by_signing_up_y)

)
